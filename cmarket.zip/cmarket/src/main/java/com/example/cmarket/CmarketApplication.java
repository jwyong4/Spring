package com.example.cmarket;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CmarketApplication {

	public static void main(String[] args) {
		SpringApplication.run(CmarketApplication.class, args);
	}

}

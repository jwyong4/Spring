package com.codestates.section3week1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Section3Week1Application {

	public static void main(String[] args) {
		SpringApplication.run(Section3Week1Application.class, args);
	}

}

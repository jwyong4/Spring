package com.codestates;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Section2Week3Application {

	public static void main(String[] args) {
		SpringApplication.run(Section2Week3Application.class, args);
	}

}
